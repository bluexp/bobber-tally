---
name: apple-app-release
description: 发布 macOS 应用或上架 iOS App Store。用于 Mac Developer ID 签名、公证、官网分发、Sparkle 自动更新，以及 iOS 构建上传、TestFlight、App Review 和上架。
---

# Apple 应用发布

- Mac 官网分发或 Sparkle 更新，读 [macos.md](references/macos.md)。
- iOS App Store 或 TestFlight，读 [ios.md](references/ios.md)。
- WFDB Mac 客户端，额外读 [wfdb.md](references/wfdb.md)，复用项目已有脚本和发布路径。

从项目、现有发行记录和用户要求确认应用、Apple 团队、Bundle ID、版本、构建号、发布目标及本次终点。优先复用现有构建流程、有效签名身份、钥匙串配置和已登录会话。项目里有他人正在编辑的内容时，隔离需要上传的文件，依照当前项目的分支和部署流程工作。

协助准备、上传构建、提交审核、正式上线分别以用户这次要求的终点为准。发出的构建、包、受众或发布方式超出已授权范围时，先准备可核对的内容，再说明需要确认的具体决定。需要用户完成 Apple 登录、双重认证、协议确认、私钥授权或本机输入凭据时，直接提供当前状态、入口和完成标志，继续处理不依赖该步骤的工作。凭据、私钥和审核账号保存在项目认可的安全存储中。公开产物只包含发布所需内容。

对照最终产物和外部状态验证任务是否完成。记录可复查的应用版本与构建号、相关公证或审核状态、下载或商店入口，以及任何尚未验证的环节。Apple 处理尚未完成时，保留提交标识并按用户要求的终点跟进。
