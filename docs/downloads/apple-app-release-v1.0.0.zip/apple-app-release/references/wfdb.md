# WFDB Mac 客户端

在 WFDB 工作区检查 `clients/macos/Info.plist`、`clients/macos/build.sh` 和当前网站下载列表。保持 `cc.wfdb.companion`、原 Sparkle 公钥及清单地址。推进公开版本和 `CFBundleVersion`，运行 `./clients/macos/build.sh --release`。用项目配置实际指定的本机钥匙串条目。首次或换机时从维护者处恢复匹配的更新签名密钥。

脚本在 `clients/macos/build/release/` 生成版本化的 `WFDB-macOS-v*.zip` 和 `wfdb-macos-appcast.xml`。脚本已配置 Apple 公证的区域端点。若 Sparkle 工具停在系统钥匙串许可窗口，让用户核对提示中的工具和项目密钥，按需要授权。

在现行 GitHub Pages 源分支，将这两个产物部署到 `docs/downloads/`，同步更新 `docs/index.html` 和 `docs/en/index.html`。把网站改动与工作区里无关的代码改动隔离。上线后同时核对两个首页、发布包和清单，在隔离副本上验证一次升级。分发包应包含支持的 Apple 芯片和 Intel 架构。测试外置游戏盘尚未响应的场景时，更新入口和设置仍应可操作。

从无 Sparkle 的客户端迁移时，提示用户从官网下载解压并拖入「应用程序」一次。WFDB 自身更新入口位于应用菜单，BobberTally 游戏插件通过客户端的「插件」页管理。 [WFDB 下载入口](https://wfdb.cc/)
