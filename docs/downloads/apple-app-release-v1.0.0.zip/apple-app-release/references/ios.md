# iOS App Store 上架

## 确认目标与准备构建

1. 用项目配置和 App Store Connect 核对 Apple 团队、应用记录、Bundle ID、版本和构建号。更新已有 App 时沿用原记录和 Bundle ID，确认项目配置中的版本与商店目标一致。首次上架时在上传前创建应用记录并选择正确的 App ID。提交 TestFlight、提交 App Review 和正式发布各自有独立状态。 [App Store Connect 工作流](https://developer.apple.com/help/app-store-connect/get-started/app-store-connect-workflow/) · [添加新 App](https://developer.apple.com/help/app-store-connect/create-an-app-record/add-a-new-app/)
2. 每次提交前核对 Apple 当前要求的 Xcode 和 SDK。项目使用 Xcode 自动签名时沿用团队和自动签名配置。手动签名时核对 Apple Distribution 证书、应用与扩展各自的 App Store 描述文件、entitlements 和 Bundle ID。iOS 此流程通过 App Store Connect 分发。 [当前提交要求](https://developer.apple.com/news/upcoming-requirements/) · [App Store 描述文件](https://developer.apple.com/help/account/provisioning-profiles/create-an-app-store-provisioning-profile/)
3. 依照项目现有测试和 Release 工作流归档。确认签名、目标平台、版本、构建号和发行环境，再通过现有 CI、Xcode Organizer 或 Transporter 上传。上传成功后等待 App Store Connect 处理，并确认正确的构建可被选择。重复构建号报错时检查是否已存在同一构建，再根据项目规则递增。若只要求 TestFlight，按授权处理内测或外测、所需 Beta App Review 和测试组。 [上传构建](https://developer.apple.com/help/app-store-connect/manage-builds/upload-builds/) · [TestFlight](https://developer.apple.com/testflight/)

## 准备商店信息并送审

- 按版本和地区填实际需要的名称、描述、截图、更新说明、支持链接和隐私政策链接。隐私披露基于当前 App 与第三方 SDK 的实际行为。核对年龄分级、隐私清单和所需原因 API，以及出口合规或其他按功能触发的资料。依照源码、依赖和用户确认的信息回答，事实不明确时向负责人员核对。
- 审核说明应让审核人员知道怎样访问关键功能。若应用需要登录，使用具备适当权限的审核专用账号，并在授权的 App Review 信息字段提交审核所需内容。价格、地区和发布方式沿用用户已确认的设置或项目惯例。有实质变化且用户意图不明时，带着可核对的草稿说明需要决定的事项。
- 选择正确构建，完成校验后依授权执行 `Add for Review` 与 `Submit for Review`。通过 App Store Connect 的状态确认送审。遇到 Apple 补件或拒绝时，读取具体反馈，修复可处理的内容，并根据实际状态选择回复、换构建或重新提交。

[隐私披露](https://developer.apple.com/app-store/app-privacy-details/) · [选择构建](https://developer.apple.com/help/app-store-connect/manage-builds/choose-a-build-to-submit/) · [App Review 指南](https://developer.apple.com/app-store/review/) · [提交审核](https://developer.apple.com/help/app-store-connect/manage-submissions-to-app-review/submit-an-app/)

## 确认上架与人工节点

按用户授权的终点跟进。自动发布、手动发布及适用的分阶段发布采用项目选定的方式。若用户要求上线，在审核通过且版本待手动发布时完成获授权的发布动作，最终核对目标地区的公开商店页与上线版本。若任务只要求准备、上传或送审，在相应状态交付版本、构建号和待处理事项。

需要本人登录、双重认证、签署协议、提供只有账号持有人知道的合规事实，或授权尚未决定的发行条件时，说明当前缺口和官方操作入口。继续准备其余所需内容，完成后只报告已有证据的状态。

[Apple 发布选项](https://developer.apple.com/help/app-store-connect/manage-your-apps-availability/overview-of-publishing-your-app-on-the-app-store/) · [版本和审核状态](https://developer.apple.com/help/app-store-connect/reference/app-information/app-and-submission-statuses/)
