# macOS 官网分发

## 识别已有发行配置

1. 读取项目的 Release 构建入口、Bundle ID、版本号、构建号、支持的 macOS 和架构，以及上一个公开版本。发布更新时沿用 Bundle ID，推进公开版本和构建号，并尽量保持发行签名身份的连续性。
2. 用 `security find-identity -v -p codesigning` 核对目标团队的 Developer ID Application 身份。证书缺失时先找现有证书及其对应私钥。首次申请本地 Developer ID 证书时，由 Account Holder 在 Xcode 或 Apple Developer 门户办理；具备专门权限的管理员可使用云托管证书。网页申请使用本机钥匙串生成的 CSR，下载并导入证书后验证它与本机私钥配对。遇到 `PLA Update available` 时，让 Account Holder 查看当前开发者协议，随后重新检查证书权限。 [Apple 证书说明](https://developer.apple.com/help/account/certificates/create-developer-id-certificates/) · [账号角色](https://developer.apple.com/help/account/access/roles/)
3. 检查项目使用的 `notarytool` 钥匙串配置，例如 `xcrun notarytool history --keychain-profile "$profile"`。若使用已登录的 Xcode Organizer，可以沿用其 Developer ID 分发流程。若使用 `notarytool` 且缺少凭据，可使用已有获授权的 App Store Connect API 密钥，或请用户在 Apple Account 生成 App 专用密码，再在本机终端安全输入。将下列示例值替换为该团队的信息，等待 `Credentials saved to Keychain`。出现 401 时核对账号、团队和密码种类。 [公证工作流](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow) · [App 专用密码](https://support.apple.com/102654)

```sh
xcrun notarytool store-credentials "PROJECT-Notary" \
  --apple-id 'DEVELOPER_APPLE_ID' --team-id 'DEVELOPER_TEAM_ID'
```

## 签名、公证和验证

1. 用项目 Release 流程构建。在 Xcode 的 Developer ID 分发流程中导出，或通过 `codesign` 对嵌套代码从内到外签名。为需要的目标启用 Hardened Runtime 和安全时间戳，保留实际需要的 entitlements，检查分发构建没有调试权限。对最终应用执行 `codesign --verify --deep --strict --verbose=2 "$app"`，通过 `codesign -dv --verbose=4 "$app"` 检查签名团队、时间戳与运行时选项。发布签名 PKG 时，应用使用 Developer ID Application，安装包使用 Developer ID Installer。 [Apple 分发签名](https://developer.apple.com/documentation/xcode/creating-distribution-signed-code-for-the-mac) · [分发打包](https://developer.apple.com/documentation/xcode/packaging-mac-software-for-distribution)
2. 将签好的应用装入 ZIP、DMG 或 PKG，提交公证。ZIP 示例使用 `ditto -c -k --sequesterRsrc --keepParent "$app" "$submission_zip"`。保留公证提交 ID，并查询同一次提交，直到 `Accepted` 或明确失败。若加速端点连接超时，核实网络后可加 `--no-s3-acceleration` 使用 Apple 文档列出的区域端点。提交已上传且正在审查时继续查询该提交。失败时用 `notarytool log` 定位具体文件，修正再提交。 [Apple 公证工作流](https://developer.apple.com/documentation/security/customizing-the-notarization-workflow)

```sh
xcrun notarytool submit "$submission_zip" --keychain-profile "$profile" --wait
xcrun notarytool info "$submission_id" --keychain-profile "$profile"
xcrun notarytool log "$submission_id" --keychain-profile "$profile"
```

3. 公证通过后运行 `xcrun stapler staple "$app"` 和 `xcrun stapler validate "$app"`。ZIP 分发时给里面的应用附上票据，再用 `ditto` 重新打包。分发已公证的 DMG 或 PKG 时，按 Apple 指引给对应容器附票据。
4. 将最终下载包解压到独立目录，再检查票据、签名和所承诺的架构。应用分发使用 `syspolicy_check distribution "$app"` 或 `spctl --assess --type execute --verbose=2 "$app"`，按当前 macOS 支持的工具选择。在可行时，从干净的安装位置启动，测试首次打开和关键功能。 [Apple 公证与首次运行](https://developer.apple.com/documentation/security/notarizing-macos-software-before-distribution)

## Sparkle 自动更新

1. 从项目确认 Sparkle 版本和接入方式。新接入可采用官方发行版，保持其最低系统和目标架构兼容性，并保留许可证。启用标准更新器、手动检查入口和适合产品的自动检查与安装设置。对随应用分发的框架、帮助程序和 XPC 服务签名，之后再签外层应用。 [Sparkle 接入指南](https://sparkle-project.org/documentation/) · [SwiftUI 示例](https://sparkle-project.org/documentation/programmatic-setup/)
2. 沿用现有 HTTPS `SUFeedURL`、`SUPublicEDKey` 及对应私钥。首次接入使用 Sparkle 的 `generate_keys` 生成项目专用钥匙串条目，只将公钥嵌入应用。Sparkle 2.9 起可开启 `SURequireSignedFeed` 来校验清单和发行说明，并须同时开启 `SUVerifyUpdateBeforeExtraction`。生成清单后如需手动修改，先为变更过的外置发行说明更新签名属性，再用 `sign_update` 为最终清单签名。密钥迁移或丢失时按 Sparkle 的轮换流程验证旧客户端的升级路径。 [更新签名设置](https://sparkle-project.org/documentation/customization/) · [密钥轮换](https://sparkle-project.org/documentation/#rotating-signing-keys)
3. 公证、附票据并生成最终下载包后，才用 `generate_appcast` 生成更新清单和归档签名。核对清单的构建号、最低系统、HTTPS 地址、文件长度及签名，保持已经发布的 ZIP 字节和 URL 稳定。同次部署新 ZIP、签名清单及所需发行说明，或先让 ZIP 可访问再更新清单。 [Sparkle 发布文档](https://sparkle-project.org/documentation/publishing/)
4. 部署后重新下载公开包与清单，与本地验证产物比较。用可写目录下的独立旧版本副本验证发现更新、下载安装并重启到预期构建。首次引入 Sparkle 时，告知现有无更新器的用户需要手动安装一次。使用正式签名、Apple 公证和公开 HTTPS 地址进行更新测试。

## 官网交付

按照现有站点发布流程更新下载入口和必要的安装说明，等部署完成后测试公开地址、目标版本和下载的文件哈希。若同一提交中的上线状态尚未确认，报告已推送或部署中，直到能取得线上文件。发布后给出直接下载链接、版本和兼容范围。
